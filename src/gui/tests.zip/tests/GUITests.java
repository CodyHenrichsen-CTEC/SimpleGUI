/**
 * 
 */
package gui.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * @author CodyH
 * @version 0.x Nov 13, 2015
 *
 */
@RunWith(Suite.class)
@SuiteClasses({ GUIFrameTest.class, GUIPanelTest.class })
public class GUITests
{

}
